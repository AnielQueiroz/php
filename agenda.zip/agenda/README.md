## Agenda em PHP

*Um sistema de agenda em PHP para fins de estudos do PDO e conexão com MySQL.*

**Tecnologias usadas:**
- PHP (PDO)
- MySQL (PHP Admin)
- Bootstrap
- Font Awesome